import pandas as pd
import numpy as np
import torch
import torch.nn as nn
from sklearn.metrics import accuracy_score
import time

# --- 数据加载 ---
X_train_df = pd.read_excel('X_train.xlsx')
y_train_df = pd.read_excel('y_train.xlsx')
X_val_df = pd.read_excel('X_val.xlsx')
y_val_df = pd.read_excel('y_val.xlsx')
X_test_df = pd.read_excel('X_test.xlsx')
y_test_df = pd.read_excel('y_test.xlsx')

# 转换为NumPy数组
X_train = X_train_df.values
y_train = y_train_df.values.ravel()
X_val = X_val_df.values
y_val = y_val_df.values.ravel()
X_test = X_test_df.values
y_test = y_test_df.values.ravel()

# 打印数据形状
print(f"X_train shape: {X_train.shape}, y_train shape: {y_train.shape}")
print(f"X_val shape: {X_val.shape}, y_val shape: {y_val.shape}")
print(f"X_test shape: {X_test.shape}, y_test shape: {y_test.shape}")


# --- 数据预处理 ---
def normalize_data(X):
    X_normalized = np.zeros_like(X)
    for i in range(X.shape[1]):
        feature_col = X[:, i]
        lower = np.percentile(feature_col, 2)
        upper = np.percentile(feature_col, 98)
        norm_col = (feature_col - lower) / (upper - lower + 1e-6)
        norm_col = np.clip(norm_col, 0, 1)
        X_normalized[:, i] = norm_col
    return X_normalized


X_train = normalize_data(X_train)
X_val = normalize_data(X_val)
X_test = normalize_data(X_test)

# 调整维度适应LSTM输入
X_train = X_train.reshape(X_train.shape[0], -1, 8)
X_val = X_val.reshape(X_val.shape[0], -1, 8)
X_test = X_test.reshape(X_test.shape[0], -1, 8)

print(f"调整后的维度 - X_train: {X_train.shape}, X_val: {X_val.shape}, X_test: {X_test.shape}")

# 转换为PyTorch张量
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
X_train_tensor = torch.tensor(X_train, dtype=torch.float32).to(device)
y_train_tensor = torch.tensor(y_train, dtype=torch.long).to(device)
X_val_tensor = torch.tensor(X_val, dtype=torch.float32).to(device)
y_val_tensor = torch.tensor(y_val, dtype=torch.long).to(device)
X_test_tensor = torch.tensor(X_test, dtype=torch.float32).to(device)
y_test_tensor = torch.tensor(y_test, dtype=torch.long).to(device)

# 确定类别数量
all_classes = np.unique(np.concatenate((y_train, y_val, y_test)))
output_size = len(all_classes)
print(f"检测到 {output_size} 个类别: {all_classes}")

# 类别权重和损失函数
class_weights = torch.ones(output_size, device=device)
criterion = nn.CrossEntropyLoss(weight=class_weights)


# --- LSTM模型 ---
class ModifiedLSTMModel(nn.Module):
    def __init__(self, input_size, hidden_size, output_size, num_layers=5, dropout_prob=0.2):
        super(ModifiedLSTMModel, self).__init__()
        self.lstm = nn.LSTM(
            input_size=input_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout_prob,
            bidirectional=False
        )
        self.fc1 = nn.Linear(hidden_size, hidden_size)
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(dropout_prob)
        self.output_layer = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        lstm_out, (h_n, c_n) = self.lstm(x)
        out = h_n[-1]
        out = self.fc1(out)
        out = self.relu(out)
        out = self.dropout(out)
        out = self.output_layer(out)
        return out


# --- 超参数 ---
input_size = 8
hidden_size = 100
output_size = output_size
num_layers = 5
batch_size = 32
learning_rate = 0.001
dropout_prob = 0.2
num_epochs = 10

# 初始化模型、优化器和调度器
model = ModifiedLSTMModel(input_size, hidden_size, output_size, num_layers, dropout_prob).to(device)
optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=num_epochs)


# --- 训练函数 ---
def train_model(model, criterion, optimizer, scheduler, train_data, train_labels, val_data, val_labels,
                batch_size, num_epochs, device):
    train_losses = []
    val_losses = []
    train_accuracies = []
    val_accuracies = []

    print(f"开始训练，设备: {device}")
    start_time = time.time()

    for epoch in range(num_epochs):
        model.train()
        running_train_loss = 0.0
        correct_train = 0
        total_train = 0

        for i in range(0, len(train_data), batch_size):
            batch_x = train_data[i:i + batch_size]
            batch_y = train_labels[i:i + batch_size]

            optimizer.zero_grad()
            output = model(batch_x)
            loss = criterion(output, batch_y)
            loss.backward()
            optimizer.step()

            running_train_loss += loss.item()
            _, predicted = torch.max(output, 1)
            correct_train += (predicted == batch_y).sum().item()
            total_train += batch_y.size(0)

        train_loss = running_train_loss / len(train_data)
        train_accuracy = correct_train / total_train * 100
        train_losses.append(train_loss)
        train_accuracies.append(train_accuracy)

        scheduler.step()

        # 验证阶段
        model.eval()
        running_val_loss = 0.0
        correct_val = 0
        total_val = 0

        with torch.no_grad():
            for i in range(0, len(val_data), batch_size):
                batch_x = val_data[i:i + batch_size]
                batch_y = val_labels[i:i + batch_size]

                output = model(batch_x)
                loss = criterion(output, batch_y)
                running_val_loss += loss.item()

                _, predicted = torch.max(output, 1)
                correct_val += (predicted == batch_y).sum().item()
                total_val += batch_y.size(0)

        val_loss = running_val_loss / len(val_data)
        val_accuracy = correct_val / total_val * 100
        val_losses.append(val_loss)
        val_accuracies.append(val_accuracy)

        current_lr = optimizer.param_groups[0]['lr']
        epoch_time = time.time() - start_time
        print(f"Epoch [{epoch + 1}/{num_epochs}], "
              f"LR: {current_lr:.6f}, "
              f"Train Loss: {train_loss:.4f}, Train Acc: {train_accuracy:.2f}%, "
              f"Val Loss: {val_loss:.4f}, Val Acc: {val_accuracy:.2f}%, "
              f"Time: {epoch_time:.2f}s")

    total_training_time = time.time() - start_time
    print(f"\n训练完成！总耗时: {total_training_time:.2f} 秒")

    return train_losses, val_losses, train_accuracies, val_accuracies


# --- 执行训练 ---
train_losses, val_losses, train_accuracies, val_accuracies = train_model(
    model, criterion, optimizer, scheduler, X_train_tensor, y_train_tensor,
    X_val_tensor, y_val_tensor, batch_size, num_epochs, device
)

# --- 测试模型（添加测试开始标记，方便后续计算纯测试能耗）---
print("=== 开始测试阶段 ===")  # 这个标记用于区分训练和测试阶段
test_start_time = time.time()

model.eval()
with torch.no_grad():
    y_pred = model(X_test_tensor)
    _, predicted = torch.max(y_pred, 1)
    test_accuracy = accuracy_score(y_test_tensor.cpu(), predicted.cpu()) * 100
    print(f"测试集准确率: {test_accuracy:.2f}%")

test_end_time = time.time()
print(f"测试阶段耗时: {test_end_time - test_start_time:.2f}秒")