import os
import argparse
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim.lr_scheduler import CosineAnnealingLR
import time

# 设置环境变量
os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'


# --- 模型定义 ---
class ModifiedCNN(nn.Module):
    def __init__(self, input_channels=8, num_classes=3):
        super(ModifiedCNN, self).__init__()
        self.conv1 = nn.Conv1d(in_channels=input_channels, out_channels=20, kernel_size=1, padding=0)
        self.empty_conv1 = nn.Conv1d(in_channels=20, out_channels=20, kernel_size=1, padding=0)
        self.conv2 = nn.Conv1d(in_channels=20, out_channels=80, kernel_size=1, stride=1, padding=0)
        self.empty_conv2 = nn.Conv1d(in_channels=80, out_channels=80, kernel_size=1, padding=0)
        self.fc1 = nn.Linear(80 * 1, 200)
        self.empty_fc = nn.Linear(200, 200)
        self.fc2 = nn.Linear(200, num_classes)

    def forward(self, x):
        x = nn.functional.relu(self.conv1(x))
        x = nn.functional.relu(self.empty_conv1(x))
        x = nn.functional.relu(self.conv2(x))
        x = nn.functional.relu(self.empty_conv2(x))
        x = x.view(x.size(0), -1)
        x = nn.functional.relu(self.fc1(x))
        x = nn.functional.relu(self.empty_fc(x))
        x = self.fc2(x)
        return x


# --- 数据预处理函数 ---
def normalize_data(X):
    """百分位数归一化"""
    X_normalized = (X - np.percentile(X, 2, axis=1, keepdims=True)) / (
            np.percentile(X, 98, axis=1, keepdims=True) - np.percentile(X, 2, axis=1, keepdims=True))
    X_normalized[X_normalized >= 1] = 1
    X_normalized[X_normalized <= 0] = 0
    return X_normalized


def load_and_process_data(fold_dir, fold_num, input_channels=8):
    """加载并处理单折数据（训练集+测试集）"""
    # 加载当前折训练集
    train_path = f"{fold_dir}/train_fold{fold_num}.csv"
    train_data = pd.read_csv(train_path, header=None).values
    X_train = train_data[:, :-1]
    y_train = train_data[:, -1].astype(int)

    # 加载当前折测试集
    test_path = f"{fold_dir}/test_fold{fold_num}.csv"
    test_data = pd.read_csv(test_path, header=None).values
    X_test = test_data[:, :-1]
    y_test = test_data[:, -1].astype(int)

    # 数据归一化
    X_train = normalize_data(X_train)
    X_test = normalize_data(X_test)

    # 调整CNN输入维度 [样本数, 特征数, 1]
    X_train = X_train.reshape(X_train.shape[0], input_channels, 1)
    X_test = X_test.reshape(X_test.shape[0], input_channels, 1)

    # 转换为张量
    X_train_tensor = torch.tensor(X_train, dtype=torch.float32)
    y_train_tensor = torch.tensor(y_train, dtype=torch.long)
    X_test_tensor = torch.tensor(X_test, dtype=torch.float32)
    y_test_tensor = torch.tensor(y_test, dtype=torch.long)

    return X_train_tensor, y_train_tensor, X_test_tensor, y_test_tensor


# --- 训练单折模型 ---
def train_single_fold(model, criterion, optimizer, scheduler, train_data, train_labels,
                      batch_size, num_epochs, device, fold_num):
    """训练单折模型"""
    train_losses = []
    train_accs = []
    total_FLOPs = 0

    # 计算FLOPs
    def calculate_flops():
        batch_size_flops = 64
        FLOPs_conv1 = 2 * 10 * 8 * 1 * batch_size_flops * 1
        FLOPs_empty_conv1 = 2 * 10 * 10 * 1 * batch_size_flops * 1
        FLOPs_conv2 = 2 * 40 * 10 * 1 * batch_size_flops * 1
        FLOPs_empty_conv2 = 2 * 40 * 40 * 1 * batch_size_flops * 1
        FLOPs_fc1 = 2 * 40 * 100 * batch_size_flops
        FLOPs_empty_fc = 2 * 100 * 100 * batch_size_flops
        FLOPs_fc2 = 2 * 100 * 3 * batch_size_flops
        return FLOPs_conv1 + FLOPs_empty_conv1 + FLOPs_conv2 + FLOPs_empty_conv2 + FLOPs_fc1 + FLOPs_empty_fc + FLOPs_fc2

    FLOPs_iteration = calculate_flops()

    # 移动数据到设备
    train_data = train_data.to(device)
    train_labels = train_labels.to(device)

    for epoch in range(num_epochs):
        model.train()
        running_loss = 0.0
        correct = 0
        total = 0
        start_time = time.time()

        for i in range(0, len(train_data), batch_size):
            batch_x = train_data[i:i + batch_size]
            batch_y = train_labels[i:i + batch_size]

            optimizer.zero_grad()
            output = model(batch_x)
            loss = criterion(output, batch_y)
            loss.backward()
            optimizer.step()

            running_loss += loss.item() * batch_x.size(0)
            _, pred = torch.max(output, 1)
            correct += (pred == batch_y).sum().item()
            total += batch_y.size(0)
            total_FLOPs += FLOPs_iteration

        epoch_time = time.time() - start_time
        train_loss = running_loss / total
        train_acc = correct / total * 100
        train_losses.append(train_loss)
        train_accs.append(train_acc)

        print(f"Fold [{fold_num}], Epoch [{epoch + 1}/{num_epochs}], "
              f"Train Loss: {train_loss:.4f}, Train Acc: {train_acc:.2f}%, "
              f"Epoch Time: {epoch_time:.2f}s")

    return {
        'train_losses': train_losses,
        'train_accs': train_accs,
        'total_FLOPs': total_FLOPs,
        'model_state': model.state_dict()
    }


# --- 测试单折模型 ---
def test_single_fold(model, criterion, test_data, test_labels, batch_size, device):
    """测试单折模型"""
    model.eval()
    test_loss = 0.0
    test_correct = 0
    test_total = 0

    with torch.no_grad():
        for i in range(0, len(test_data), batch_size):
            batch_x = test_data[i:i + batch_size]
            batch_y = test_labels[i:i + batch_size]
            output = model(batch_x)
            loss = criterion(output, batch_y)
            test_loss += loss.item() * batch_x.size(0)
            _, pred = torch.max(output, 1)
            test_correct += (pred == batch_y).sum().item()
            test_total += batch_y.size(0)

    test_loss = test_loss / test_total
    test_acc = test_correct / test_total * 100
    return test_loss, test_acc


# --- 主函数 ---
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='10折训练/测试集的CNN模型训练')
    parser.add_argument('--fold', type=int, required=True, help='要运行的折数 (1-10)')
    parser.add_argument('--epochs', type=int, default=300, help='训练轮数')
    parser.add_argument('--batch_size', type=int, default=64, help='批量大小')
    parser.add_argument('--lr', type=float, default=0.001, help='学习率')
    parser.add_argument('--fold_dir', type=str, default='dataset_folds', help='数据集文件夹')
    parser.add_argument('--mode', type=str, default='train', choices=['train', 'test'], help='运行模式: train或test')
    args = parser.parse_args()

    fold_num = args.fold
    num_epochs = args.epochs
    batch_size = args.batch_size
    learning_rate = args.lr
    fold_dir = args.fold_dir
    mode = args.mode

    if not (1 <= fold_num <= 10):
        print("错误: 折数必须在1-10之间")
        exit(1)

    # 设备选择
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"使用设备: {device}, 运行第{fold_num}折，模式: {mode}")

    # 加载并处理当前折数据
    print(f"\n--- 加载第{fold_num}折数据 ---")
    X_train, y_train, X_test, y_test = load_and_process_data(fold_dir, fold_num)

    # 确定类别数
    output_size = len(np.unique(y_train.numpy()))
    print(f"检测到 {output_size} 个类别")

    # 计算类别权重
    class_weights = torch.ones(output_size, device=device)
    if output_size > 1:
        class_counts = torch.bincount(y_train)
        class_weights = 1.0 / class_counts.float()
        class_weights = (class_weights / class_weights.min()) * 0.5
    criterion = nn.CrossEntropyLoss(weight=class_weights)

    # 初始化模型
    model = ModifiedCNN(input_channels=8, num_classes=output_size).to(device)

    if mode == 'train':
        # 训练模式
        print("TRAINING_START")
        print(f"\n--- 开始第{fold_num}折训练 ---")

        # 初始化优化器和调度器
        optimizer = optim.Adam(model.parameters(), lr=learning_rate)
        scheduler = CosineAnnealingLR(optimizer, T_max=num_epochs)

        # 训练模型
        fold_metrics = train_single_fold(
            model, criterion, optimizer, scheduler,
            X_train, y_train, batch_size, num_epochs, device, fold_num
        )

        # 保存模型
        model_save_path = f"model_folds/cnn_model_fold{fold_num}.pth"
        os.makedirs('model_folds', exist_ok=True)
        torch.save(fold_metrics['model_state'], model_save_path)
        print(f"第{fold_num}折模型已保存至: {model_save_path}")

        # 保存训练结果
        results_save_path = f"results/cnn_fold_{fold_num}_train_results.npy"
        os.makedirs('results', exist_ok=True)
        np.save(results_save_path, fold_metrics)
        print(f"第{fold_num}折训练结果已保存至: {results_save_path}")

        print("TRAINING_END")

    elif mode == 'test':
        # 测试模式
        print("TESTING_START")
        print(f"\n--- 开始第{fold_num}折测试 ---")

        # 加载已保存的模型
        model_save_path = f"model_folds/cnn_model_fold{fold_num}.pth"
        model.load_state_dict(torch.load(model_save_path))

        # 测试模型
        test_loss, test_acc = test_single_fold(
            model, criterion, X_test, y_test, batch_size, device
        )

        # 保存测试结果
        test_results = {
            'test_loss': test_loss,
            'test_acc': test_acc
        }
        test_save_path = f"results/cnn_fold_{fold_num}_test_results.npy"
        np.save(test_save_path, test_results)

        print(f"\n--- 第{fold_num}折测试结果 ---")
        print(f"测试准确率: {test_acc:.2f}%")
        print(f"测试损失: {test_loss:.4f}")
        print(f"测试结果已保存至: {test_save_path}")
        print("\n" + "=" * 60)
        print(f"accuracy: {test_acc / 100:.4f}")
        print("=" * 60)
        print("TESTING_END")