import os
import argparse
import pandas as pd
import numpy as np
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score
import time
import joblib  # 用于保存模型

# 设置环境变量
os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'


# --- 数据预处理函数 ---
def normalize_data(X):
    """百分位数归一化"""
    X_normalized = (X - np.percentile(X, 2, axis=1, keepdims=True)) / (
            np.percentile(X, 98, axis=1, keepdims=True) - np.percentile(X, 2, axis=1, keepdims=True))
    X_normalized[X_normalized >= 1] = 1
    X_normalized[X_normalized <= 0] = 0
    return X_normalized


def load_and_process_data(fold_dir, fold_num):
    """加载并处理单折数据（训练集+测试集）"""
    # 加载当前折训练集
    train_path = f"{fold_dir}/train_fold{fold_num}.csv"
    train_data = pd.read_csv(train_path, header=None).values
    X_train = train_data[:, :-1]
    y_train = train_data[:, -1].astype(int)

    # 加载当前折测试集
    test_path = f"{fold_dir}/test_fold{fold_num}.csv"
    test_data = pd.read_csv(test_path, header=None).values
    X_test = test_data[:, :-1]
    y_test = test_data[:, -1].astype(int)

    # 数据归一化
    X_train = normalize_data(X_train)
    X_test = normalize_data(X_test)

    return X_train, y_train, X_test, y_test


# --- 训练单折模型 ---
def train_single_fold(X_train, y_train, X_test, y_test, fold_num, params):
    """训练单折SVM模型并返回指标"""
    print(f"\n--- 开始第{fold_num}折训练 ---")

    # 初始化SVM模型
    svm_model = SVC(
        kernel=params['kernel'],
        C=params['C'],
        gamma=params['gamma'],
        random_state=params['random_state'],
        probability=params['probability'],
        verbose=0
    )

    # 训练模型
    start_time = time.time()
    svm_model.fit(X_train, y_train)
    training_time = time.time() - start_time
    print(f"训练完成！总耗时: {training_time:.2f} 秒")

    # 测试模型
    y_pred = svm_model.predict(X_test)
    test_accuracy = accuracy_score(y_test, y_pred) * 100
    print(f"测试集准确率: {test_accuracy:.2f}%")

    return {
        'model': svm_model,
        'test_accuracy': test_accuracy,
        'training_time': training_time
    }


# --- 测试单折模型 ---
def test_single_fold(X_test, y_test, fold_num, model_path):
    """测试单折SVM模型并返回指标"""
    print(f"\n--- 开始第{fold_num}折测试 ---")
    # 加载模型
    svm_model = joblib.load(model_path)
    # 测试模型
    y_pred = svm_model.predict(X_test)
    test_accuracy = accuracy_score(y_test, y_pred) * 100
    print(f"测试集准确率: {test_accuracy:.2f}%")
    return test_accuracy


# --- 主函数 ---
if __name__ == "__main__":
    # 命令行参数解析
    parser = argparse.ArgumentParser(description='10折训练/测试集的SVM模型训练和测试')
    parser.add_argument('--fold', type=int, required=True, help='要运行的折数 (1-10)')
    parser.add_argument('--kernel', type=str, default='rbf', help='核函数类型: linear, rbf, poly, sigmoid')
    parser.add_argument('--C', type=float, default=1.0, help='正则化参数')
    parser.add_argument('--gamma', type=str, default='scale', help='RBF核函数的gamma参数')
    parser.add_argument('--random_state', type=int, default=42, help='随机种子')
    parser.add_argument('--probability', type=bool, default=False, help='是否启用概率估计')
    parser.add_argument('--fold_dir', type=str, default='dataset_folds', help='数据集文件夹')
    parser.add_argument('--mode', type=str, default='train', choices=['train', 'test'], help='运行模式: train 或 test')
    args = parser.parse_args()

    fold_num = args.fold
    fold_dir = args.fold_dir
    mode = args.mode

    if not (1 <= fold_num <= 10):
        print("错误: 折数必须在1-10之间")
        exit(1)

    # 模型参数
    params = {
        'kernel': args.kernel,
        'C': args.C,
        'gamma': args.gamma,
        'random_state': args.random_state,
        'probability': args.probability
    }

    print(f"使用SVM模型，运行第{fold_num}折，模式: {mode}")
    print(f"模型参数: {params}")

    # 加载并处理当前折数据
    print(f"\n--- 加载第{fold_num}折数据 ---")
    X_train, y_train, X_test, y_test = load_and_process_data(
        fold_dir, fold_num
    )

    # 确定类别数（从训练集获取）
    output_size = len(np.unique(y_train))
    print(f"检测到 {output_size} 个类别")

    if mode == 'train':
        # 训练当前折模型
        fold_metrics = train_single_fold(
            X_train, y_train, X_test, y_test,
            fold_num, params
        )

        # 保存当前折最佳模型
        model_save_path = f"model_folds/svm_model_fold{fold_num}.joblib"
        os.makedirs('model_folds', exist_ok=True)
        joblib.dump(fold_metrics['model'], model_save_path)
        print(f"第{fold_num}折模型已保存至: {model_save_path}")

        # 保存折结果
        results_save_path = f"results/svm_fold_{fold_num}_results.npy"
        os.makedirs('results', exist_ok=True)
        np.save(results_save_path, {
            'test_accuracy': fold_metrics['test_accuracy'],
            'training_time': fold_metrics['training_time'],
            'params': params
        })
        print(f"第{fold_num}折结果已保存至: {results_save_path}")

        # 输出折汇总
        print(f"\n--- 第{fold_num}折汇总 ---")
        print(f"测试准确率: {fold_metrics['test_accuracy']:.2f}%")
        print(f"训练时间: {fold_metrics['training_time']:.2f}秒")

    elif mode == 'test':
        model_path = f"model_folds/svm_model_fold{fold_num}.joblib"
        if not os.path.exists(model_path):
            print(f"错误: 第{fold_num}折的模型文件 {model_path} 不存在，请先进行训练。")
            exit(1)
        test_accuracy = test_single_fold(X_test, y_test, fold_num, model_path)
        print(f"\n--- 第{fold_num}折测试汇总 ---")
        print(f"测试准确率: {test_accuracy:.2f}%")

    print("\n" + "=" * 60)
    if mode == 'train':
        print(f"accuracy: {fold_metrics['test_accuracy'] / 100:.4f}")
    elif mode == 'test':
        print(f"accuracy: {test_accuracy / 100:.4f}")
    print("=" * 60)