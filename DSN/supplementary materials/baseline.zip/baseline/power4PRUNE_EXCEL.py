import psutil
import subprocess
import os
import signal
import time
import sys
import re
from datetime import datetime

def parse_accuracy_from_log(log_file):
    """从日志文件中解析accuracy值"""
    try:
        with open(log_file, 'r') as f:
            content = f.read()
            # 精确匹配测试集结果中的accuracy
            match = re.search(
                r'测试集结果:\s*accuracy:\s*([\d.]+)',
                content
            )
            if match:
                return float(match.group(1))
            
            # 兼容不同格式
            match_fallback = re.search(r'accuracy:\s*(\d+\.\d+)', content)
            return float(match_fallback.group(1)) if match_fallback else None
    except Exception as e:
        print(f"Error parsing accuracy from {log_file}: {str(e)}")
        return None
    
def monitor_energy(command, log_file, cpu_tdp=270, gpu_tdp=0, interval=0.1):
    """监控能耗并保存日志"""
    main_script = None
    for part in command.split():
        if part.endswith('.py'):
            main_script = os.path.basename(part)
            break

    base_gpu_power = _measure_idle_gpu_power(10)
    proc = subprocess.Popen(
        f"{command} > {log_file} 2>&1",
        shell=True,
        start_new_session=True
    )
    time.sleep(3)
    actual_pid = _get_actual_pid(proc.pid, main_script)
    cpu_cores = 64

    if not actual_pid:
        raise RuntimeError("未检测到训练进程")

    start_time = time.time()
    cpu_energy = 0.0
    gpu_energy = 0.0
    last_update = time.time()

    try:
        print(f"\n===== 开始能耗监控 @ {datetime.now()} =====\n")
        
        while True:
            current_time = time.time()
            time_diff = current_time - last_update

            total_cpu = 0.0
            try:
                main_process = psutil.Process(actual_pid)
                processes = [main_process] + main_process.children(recursive=True)
                for p in processes:
                    try:
                        total_cpu += p.cpu_percent(interval=0.1)
                    except (psutil.NoSuchProcess, psutil.AccessDenied):
                        continue
            except psutil.NoSuchProcess:
                break

            cpu_energy += (total_cpu / 100) * cpu_tdp / cpu_cores * time_diff

            current_gpu_power = _get_gpu_power()
            if current_gpu_power and base_gpu_power:
                gpu_energy += max(0, current_gpu_power - base_gpu_power) * time_diff

            print(
                f"[{datetime.now().strftime('%H:%M:%S')}] "
                f"CPU_Energy: {cpu_energy:.1f}J | "
                f"GPU_Energy: {gpu_energy:.1f}J | "
                f"GPU_Power: {current_gpu_power-base_gpu_power if current_gpu_power else 'N/A'}W\n"
            )
            last_update = current_time

            try:
                if main_process.status() in [psutil.STATUS_ZOMBIE, psutil.STATUS_DEAD]:
                    break
            except psutil.NoSuchProcess:
                break

            time.sleep(interval)

    except KeyboardInterrupt:
        _kill_process_tree(actual_pid)
        return 0, 0, 0

    elapsed = time.time() - start_time
    _kill_process_tree(actual_pid)
    return cpu_energy, gpu_energy, elapsed

import argparse

def run_fold_experiments():
    """执行20次实验（10折×2种剪枝比例）"""
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', required=True, help='配置文件路径')
    parser.add_argument('--file', required=True, help='执行文件路径')
    parser.add_argument('--model-base-path', required=True, 
                      help='模型基础路径（示例：../autodl-tmp/AHSC/saved/Pysionet_LW3Resnet0410_232308/models/）')
    parser.add_argument('--dataset', required=True, help='which dataset to use')
    args = parser.parse_args()
    
    run_id = datetime.now().strftime(r'%m%d_%H%M%S')
    config_name = os.path.splitext(os.path.basename(args.config))[0]
    
    total_results = []
    prefix = args.dataset
    if args.dataset == 'base':prefix = ""
    # 实验矩阵：10折 × 2种剪枝比例
    for fold in range(1, 11):
        for prune_amount in [0]:#, 0.8
            # 动态生成路径
            model_path = os.path.join(
                args.model_base_path,
                f"fold{prefix}{fold}",
                "checkpoint-epoch60.pth"
            )
            log_file = f"logs/{config_name}_{run_id}_{args.dataset}_p{prune_amount}_f{fold}.log"
            os.makedirs(os.path.dirname(log_file), exist_ok=True)
            
            # 构建完整命令
            # base_command = f"../miniconda3/envs/HV/bin/python ../Code2016\ new/mainFoldtest.py"
            # base_command = f"../miniconda3/envs/HV/bin/python ../Code2016\ new/k_means.py"
            base_command = f"../miniconda3/envs/HV/bin/python ../Code2016\ new/knn.py"
            # base_command = f"../miniconda3/envs/HV/bin/python ../Code2016\ new/k_meansTest.py"
            # base_command = f"../miniconda3/envs/HV/bin/python ../Code2016\ new/mainFoldtest.py"
            command = f"{base_command} --current_fold {prefix}{fold}"
            # command = (
            #     f"../miniconda3/envs/SiyuLou/bin/python {args.file} --config {args.config} "
            #     f"--model {model_path} --dataset {prefix}{fold} --mc-samples 20 " #仅LW3用
            #     f"--prune --prune-amount {prune_amount}"
            # ) # 通用测试单模型
            # command = (
            #     f"../miniconda3/envs/SiyuLou/bin/python "
            #     f"pruningTestLW2UNION.py -c1 config/config_ViT.json -c2 config/config_LW2CNN.json "
            #     f"-m1 /root/autodl-tmp/AHSC/saved/Pysionet_ViT0506_235823/models/fold{fold}/checkpoint-epoch50.pth -m2 /root/autodl-tmp/AHSC/saved/Pysionet_LW2CNN0506_201320/models/fold{fold}/checkpoint-epoch110.pth "
            #     f"--prune1 --prune2 --prune-amount1 {prune_amount} --prune-amount2 {prune_amount} "
            #     f"-w1 0.5 -w2 0.5 -fold {fold}"
            # ) # 仅UNION用,借用prune参数遍历Weight得最优0.3：0.7
            # command = (f"../miniconda3/envs/SiyuLou/bin/python "
            #     "pruningTestLW5SOFTLABEL.py   --config config/config_LW5Teacher.json"
            #     f"   --model ../autodl-tmp/AHSC/saved/Pysionet_LW5Teacher0507_093455/models/fold{prefix}{fold}/checkpoint-epoch110.pth   "
            #     f"--dataset {prefix}{fold}   --temperature 7.0   --output_dir soft_labels"

            # ) #LW5用,生成软标签
            print(f"\n{'='*30} 开始实验 [Fold {fold} | Prune {prune_amount}] {'='*30}")
            
            # 执行监控
            cpu_energy, gpu_energy, elapsed = monitor_energy(
                command=command,
                log_file=log_file,
                cpu_tdp=270,
                gpu_tdp=450
            )
            # 解析准确率
            accuracy = parse_accuracy_from_log(log_file)
            
            # 记录结果
            total_results.append({
                'fold': fold,
                'prune': prune_amount,
                'time': elapsed,
                'cpu': cpu_energy,
                'gpu': gpu_energy,
                'log': log_file,
                'acc': accuracy
            })
            
            # 写入单次结果
            with open(log_file, 'a') as f:
                f.write(f"\n实验参数：Fold {fold} | Prune {prune_amount}\n"
                        f"总耗时: {elapsed:.1f}s\n"
                        f"CPU能耗: {cpu_energy:.1f}J\n"
                        f"GPU能耗: {gpu_energy:.1f}J\n"
                        f"能耗: {gpu_energy+cpu_energy:.2f}J\n")

    # 生成汇总报告
    with open(f"summary_{config_name}_{run_id}_{prefix}.log", 'w') as f:
        f.write("实验配置汇总:\n")
        f.write(f"配置文件: {args.config}\n")
        f.write(f"模型基础路径: {args.model_base_path}\n")
        f.write(f"总实验次数: {len(total_results)}\n\n")
        
        f.write("详细结果:\n")
        total_energy = 0.0
        for res in total_results:
            line = (
                f"Fold {res['fold']:02d} | Prune {res['prune']} | "
                f"Time: {res['time']:6.1f}s | "
                f"CPU: {res['cpu']:7.1f}J | "
                f"GPU: {res['gpu']:7.1f}J | "
                f"Log: {res['log']}\n"
            )
            f.write(line)
            total_energy += res['cpu'] + res['gpu']
                # 按剪枝比例分组
        import re
        from collections import defaultdict
        grouped_results = defaultdict(list)
        for res in total_results:
            grouped_results[res['prune']].append(res)
        
        # 为每个剪枝比例生成表格
        for prune_amount, results in grouped_results.items():
            # 按fold排序结果
            sorted_results = sorted(results, key=lambda x: x['fold'])
            
            # 表格标题
            f.write(f"\n\n{'='*40} Prune Amount: {prune_amount} {'='*40}\n")
            
            # 准确率表格
            f.write("\nAccuracy Table:\n")
            f.write("Fold | Accuracy\n")
            f.write("-----\t---------\n")
            for res in sorted_results:
                acc = res['acc'] if res['acc'] is not None else 'N/A'
                f.write(f"{acc if isinstance(acc, str) else f'{acc:.4f}'}\n")
            
            # 时间表格
            f.write("\nTime Table (seconds):\n")
            f.write("Fold | Time\n")
            f.write("-----\t------\n")
            for res in sorted_results:
                f.write(f"{res['time']:.2f}\n")
            
            # 能耗表格
            f.write("\nEnergy Consumption Table (Joules):\n")
            f.write("Fold | Total Energy\n")
            f.write("-----\t-------------\n")
            for res in sorted_results:
                total_energy = res['cpu'] + res['gpu']
                f.write(f"{total_energy:.2f}\n")
        f.write(f"\n总能耗: {total_energy:.1f}J")
        f.write(f"\n平均能耗/实验: {total_energy/20:.1f}J")

# 辅助函数保持不变
def _get_actual_pid(shell_pid, target_script):
    try:
        parent = psutil.Process(shell_pid)
        for child in parent.children(recursive=True):
            cmdline = ' '.join(child.cmdline())
            if target_script and target_script in cmdline:
                return child.pid
            if 'python' in cmdline and ('pruningTestLW3NEXT' in cmdline):
                return child.pid
        return parent.pid
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        return None

def _measure_idle_gpu_power(duration=10):
    measurements = []
    end_time = time.time() + duration
    while time.time() < end_time:
        power = _get_gpu_power()
        if power is not None:
            measurements.append(power)
        time.sleep(1)
    return sum(measurements)/len(measurements) if measurements else None

def _get_gpu_power():
    try:
        output = subprocess.check_output(
            "nvidia-smi --query-gpu=power.draw --format=csv,noheader,nounits",
            shell=True,
            timeout=2
        ).decode()
        return float(re.search(r"(\d+\.\d+)", output).group(1))
    except Exception as e:
        print(f"GPU监控异常: {str(e)}")
        return None

def _kill_process_tree(root_pid):
    try:
        parent = psutil.Process(root_pid)
        children = parent.children(recursive=True)
        for child in children:
            child.terminate()
        gone, alive = psutil.wait_procs(children, timeout=3)
        for p in alive:
            p.kill()
        parent.kill()
    except psutil.NoSuchProcess:
        pass

if __name__ == "__main__":
    run_fold_experiments()