import psutil
import subprocess
import os
import time
import re
from datetime import datetime
import sys


def set_high_performance():
    """设置系统高性能模式"""
    if os.name == 'nt':
        os.system('powercfg /setactive SCHEME_MIN')
    elif sys.platform == 'linux':
        os.system('sudo cpupower frequency-set --governor performance')


def monitor_energy(command, log_file, cpu_tdp=105, interval=0.01):
    """高精度能耗监测"""
    set_high_performance()

    energy_data = {
        'total': 0.0,
        'start': time.time(),
        'cpu_cores': max(psutil.cpu_count(logical=True), 4),
        'last_measure': time.time()
    }

    def calculate():
        try:
            # 获取所有进程的CPU使用率（包括系统负载）
            total_cpu = psutil.cpu_percent(interval=interval) * energy_data['cpu_cores']
            time_diff = time.time() - energy_data['last_measure']
            energy = (total_cpu / 100) * cpu_tdp * time_diff
            energy_data['total'] += energy
            energy_data['last_measure'] = time.time()

            print(
                f"[{datetime.now().strftime('%H:%M:%S.%f')[:12]}] "
                f"瞬时功率: {energy / time_diff:.1f}W | "
                f"累计能耗: {energy_data['total']:.1f}J"
            )
            return True
        except Exception as e:
            print(f"[监控错误] {str(e)}")
            return False

    with open(log_file, 'w') as log_f:
        proc = subprocess.Popen(
            command.split(),
            stdout=log_f,
            stderr=subprocess.STDOUT,
            creationflags=subprocess.CREATE_NEW_PROCESS_GROUP
        )

        try:
            while True:
                if not calculate():
                    break
                if proc.poll() is not None:
                    break
                # 动态调整采样间隔防止过热
                if energy_data['total'] > 500:  # 超过500J后降低频率
                    interval = max(interval, 0.05)
        finally:
            try:
                proc.terminate()
                proc.wait(timeout=5)
            except:
                pass

    return energy_data['total'], time.time() - energy_data['start']


def parse_accuracy(log_file):
    """解析日志中的准确率"""
    try:
        with open(log_file, 'r') as f:
            content = f.read()
            match = re.search(r"accuracy:\s*(\d+\.\d+)", content)
            if match:
                return float(match.group(1))
    except Exception as e:
        print(f"[日志解析错误] {str(e)}")
    return 0.0


def run_experiments():
    os.makedirs("logs", exist_ok=True)
    results = []

    for fold in range(1, 11):
        log_file = f"logs/CNN_test_fold{fold}.log"
        print(f"\n=== 第 {fold} 折测试 ===")

        for attempt in range(3):  # 最多重试3次
            try:
                energy, duration = monitor_energy(
                    f"python CNN.py --fold {fold} --mode test",  # 修改为CNN测试命令
                    log_file,
                    cpu_tdp=105,
                    interval=0.005
                )

                acc = parse_accuracy(log_file)
                results.append({
                    'fold': fold,
                    'energy': round(energy, 1),
                    'time': round(duration, 1),
                    'accuracy': round(acc, 4)
                })
                print(f"能耗: {energy:.1f}J | 准确率: {acc:.2f}%")
                break
            except Exception as e:
                if attempt == 2:
                    results.append({'fold': fold, 'error': str(e)})
                    print(f"测试失败: {str(e)}")
                time.sleep(5)

    # 生成专业报告
    report = [
        "=== CNN高负载测试报告 ===",  # 修改报告标题
        f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        "折数 |  能耗(J) | 耗时(s) | 准确率(%)",
        "-----|----------|---------|----------"
    ]

    total_energy = 0
    valid_results = 0
    for r in results:
        if 'error' in r:
            report.append(f"{r['fold']:4d} | {'ERROR':>9} | {'ERROR':>7} | {r['error']}")
        else:
            report.append(
                f"{r['fold']:4d} | {r['energy']:>9.1f} | "
                f"{r['time']:>7.1f} | {r['accuracy']:>9.2f}"
            )
            total_energy += r['energy']
            valid_results += 1

    report.extend([
        "\n汇总统计:",
        f"总能耗: {total_energy:.1f}J",
        f"平均每折能耗: {total_energy / valid_results if valid_results > 0 else 0:.1f}J",
        f"最高单折能耗: {max(r.get('energy', 0) for r in results):.1f}J"
    ])

    report_content = "\n".join(report)
    print("\n" + report_content)

    with open(f"CNN_HighLoad_Report_{datetime.now().strftime('%m%d_%H%M')}.txt", 'w') as f:
        f.write(report_content)


if __name__ == "__main__":
    try:
        # 设置最高进程优先级
        if os.name == 'nt':
            try:
                import win32api
                import win32process

                handle = win32api.GetCurrentProcess()
                win32process.SetPriorityClass(handle, win32process.REALTIME_PRIORITY_CLASS)
            except ImportError:
                print("警告: 未找到win32api模块，无法设置进程优先级")

        run_experiments()
    except KeyboardInterrupt:
        print("\n测试被用户中断")
        sys.exit(1)
    except Exception as e:
        print(f"\n[致命错误] {str(e)}")
        sys.exit(1)