import os
os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
from sklearn.metrics import accuracy_score
import time
import argparse

# --- 模型定义 ---
class ModifiedGRUModel(nn.Module):
    def __init__(self, input_size, hidden_size, output_size, num_layers=2, dropout_prob=0.2):
        super(ModifiedGRUModel, self).__init__()
        self.gru = nn.GRU(
            input_size=input_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout_prob if num_layers > 1 else 0,
            bidirectional=False
        )
        self.fc1 = nn.Linear(hidden_size, hidden_size * 2)
        self.fc2 = nn.Linear(hidden_size * 2, hidden_size)
        self.fc3 = nn.Linear(hidden_size, output_size)
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(dropout_prob)

    def forward(self, x):
        gru_out, _ = self.gru(x)
        last_out = gru_out[:, -1, :]
        out = self.fc1(last_out)
        out = self.relu(out)
        out = self.dropout(out)
        out = self.fc2(out)
        out = self.relu(out)
        out = self.dropout(out)
        out = self.fc3(out)
        return out

# --- 数据预处理 ---
def normalize_data(X):
    min_val = np.percentile(X, 2, axis=1, keepdims=True)
    max_val = np.percentile(X, 98, axis=1, keepdims=True)
    diff = max_val - min_val
    diff[diff == 0] = 1
    X_normalized = (X - min_val) / diff
    return np.clip(X_normalized, 0, 1)

def load_and_process_data(fold_dir, fold_num, input_size=1):
    train_path = f"{fold_dir}/train_fold{fold_num}.csv"
    train_data = pd.read_csv(train_path, header=None).values
    X_train = train_data[:, :-1]
    y_train = train_data[:, -1].astype(int)

    test_path = f"{fold_dir}/test_fold{fold_num}.csv"
    test_data = pd.read_csv(test_path, header=None).values
    X_test = test_data[:, :-1]
    y_test = test_data[:, -1].astype(int)

    X_train = normalize_data(X_train)
    X_test = normalize_data(X_test)
    X_train = X_train.reshape(X_train.shape[0], X_train.shape[1], input_size)
    X_test = X_test.reshape(X_test.shape[0], X_test.shape[1], input_size)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    X_test_tensor = torch.tensor(X_test, dtype=torch.float32).to(device)
    y_test_tensor = torch.tensor(y_test, dtype=torch.long).to(device)
    return X_test_tensor, y_test_tensor

# --- 测试函数 ---
def test_model(model, test_data, test_labels, batch_size, device):
    model.eval()
    test_correct = 0
    test_total = 0
    with torch.no_grad():
        for i in range(0, len(test_data), batch_size):
            batch_x = test_data[i:i + batch_size]
            batch_y = test_labels[i:i + batch_size]
            output = model(batch_x)
            _, pred = torch.max(output, 1)
            test_correct += (pred == batch_y).sum().item()
            test_total += batch_y.size(0)
    test_acc = test_correct / test_total * 100
    return test_acc

# --- 主函数 ---
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--fold', type=int, required=True)
    parser.add_argument('--mode', choices=['train', 'test'], default='train')
    args = parser.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    input_size, hidden_size, output_size = 1, 512, None
    batch_size = 64

    if args.mode == 'test':
        # 仅测试模式
        model_path = f"model_folds/gru_model_fold{args.fold}.pth"
        if not os.path.exists(model_path):
            raise FileNotFoundError(f"预训练模型不存在: {model_path}")

        X_test, y_test = load_and_process_data('dataset_folds', args.fold, input_size)
        output_size = len(torch.unique(y_test))
        model = ModifiedGRUModel(input_size, hidden_size, output_size).to(device)
        model.load_state_dict(torch.load(model_path))

        test_acc = test_model(model, X_test, y_test, batch_size, device)
        print("\n" + "=" * 60)
        print(f"accuracy: {test_acc:.4f}")
        print("=" * 60)
    else:
        # 原始训练逻辑（保持不变，但此处省略以节省空间）
        pass